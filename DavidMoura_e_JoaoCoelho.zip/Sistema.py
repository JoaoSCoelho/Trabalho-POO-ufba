from Cliente import Cliente

class Sistema:
    def __init__(self):
        self.clientes = []
    
    def cadastrarCliente(self, nome, identificacao, eh_empresa):
        cliente = Cliente(nome,identificacao,eh_empresa)
        self.clientes.append(cliente)

    def removerCliente(self, identificacao):
        for cliente in self.clientes:
            if (cliente.cpf == identificacao or cliente.cnpj == identificacao):
                self.clientes.remove(cliente)

    def buscarCliente(self, identificacao):
        for cliente in self.clientes:
            if (cliente.cpf == identificacao or cliente.cnpj == identificacao):
                return cliente
        return None