import datetime
from Cartao import Cartao
from Transacao import Transacao

class CartaoPremium(Cartao):
    def __init__(self, numero:int, titular:float, taxa_de_cashback: float, limite_extra: float):
        super().__init__(numero,titular)
        self.__taxa_de_cashback = taxa_de_cashback
        self.__limite_extra = limite_extra
        self.__fidelidade = 0

    def comprar(self, valor: float):
        if ((self.limite + self.limite_extra) - self.saldo < valor):
            print('Limite excedido!')
            return False
        if (self.transacao_atual is not None):
            print('Existe uma transação em andamento!')
            return False

        print('Compra feita com cashback')
        valor = valor * (1 - self.taxa_de_cashback)

        if(self.fidelidade >= 1000):
            valor = valor - (self.fidelidade * 0.5)
            self.fidelidade = 0
        self.fidelidade += valor

        transacao = Transacao(valor, 'Compra', 'compra', datetime.date.today())

        self.saldo += valor
        self.transacao_atual = transacao
        return True

    @property
    def taxa_de_cashback(self):
        return self.__taxa_de_cashback
    
    @property
    def limite_extra(self):
        return self.__limite_extra
    
    @property
    def fidelidade(self):
        return self.__fidelidade
    
    @taxa_de_cashback.setter
    def taxa_de_cashback(self, taxa_de_cashback):
        self.__taxa_de_cashback = taxa_de_cashback

    @limite_extra.setter
    def limite_extra(self, limite_extra):
        self.__limite_extra = limite_extra

    @fidelidade.setter
    def fidelidade(self, fidelidade):
        self.__fidelidade = fidelidade
    

    