from Cliente import Cliente
from Cartao import Cartao
from Transacao import Transacao
from Sistema import Sistema
from time import sleep

sistema = Sistema()





def cadastrarCliente():
    nome = input('Digite o nome do cliente: ')
    eh_empresa = False
    identificacao = input('Digite o CPF/CNPJ do cliente: ')

    if (nome == ""):
        print('Nome é obrigatório!')
        return cadastrarCliente()
    if (not identificacao.isdigit()):
        print('CPF/CNPJ deve ser numérico!')
        return cadastrarCliente()

    if (len(identificacao) == 11): 
        eh_empresa = True
    else:
        identificacao = int(identificacao)

    sistema.cadastrarCliente(nome, identificacao, eh_empresa)
    print(f'Cliente {nome} cadastrado com sucesso!')
    return

def cadastrarCartao():
    id_cliente = input('Digite o CPF/CNPJ do cliente: ')
    if (len(id_cliente) != 11): id_cliente = int(id_cliente)
    numero = int(input('Digite o número do cartao: '))
    titular = input('Quem é o titular do cartão? ')
    eh_corporativo = type(id_cliente) == int
    eh_especial = input('É um cartão especial? (S/N)')
    if (eh_especial == "S"):
        eh_especial = True
    else:
        eh_especial = False

    if (numero <= 0):
        print('Número do cartão não pode ser menor ou igual a zero!')
        return cadastrarCartao()
    
    if (titular == ''):
        print('Titular é obrigatório!')
        return cadastrarCartao()

    
    cliente: Cliente = sistema.buscarCliente(id_cliente)

    if (not cliente):
        print("Cliente não encontrado!")
        return cadastrarCartao()
    
    cliente.criar_cartao(numero,titular, eh_especial, eh_corporativo, 10000, 2000, 0.05)
    print(f'Cartao {numero} do cliente {cliente.nome} cadastrado com sucesso')
    return




if __name__ == "__main__":
    running = True
    while (running):
        operacao = int(
            input('O que deseja?\n1 - Cadastrar cliente\n2 - Cadastrar cartao\n0 - Sair')
        )

        if (operacao == 1): cadastrarCliente()
        elif (operacao == 2): cadastrarCartao()
        elif (operacao == 0): 
            running = False
    