import datetime
from Cartao import Cartao
from Transacao import Transacao

class CartaoEmpresarial(Cartao):
    def __init__(self, numero: int , titular: str, limite: float, limite_extra: float):
        super().__init__(numero,titular)
        self.limite = limite
        self.__limite_extra = limite_extra

    def comprar(self, valor: float,qtd_parcelas: int):
        if ((self.limite + self.limite_extra) - self.saldo < valor):
            print('Limite excedido!')
            return False
        if (self.transacao_atual is not None):
            print('Existe uma transação em andamento!')
            return False
        
        valor = valor / qtd_parcelas
        transacao = Transacao(valor, 'Compra', 'compra', datetime.date.today())

        self.saldo += valor
        self.transacao_atual = transacao
        return True

    
    @property
    def limite_extra(self):
        return self.__limite_extra

    @limite_extra.setter
    def limite_extra(self, limite_extra):
        self.__limite_extra = limite_extra
